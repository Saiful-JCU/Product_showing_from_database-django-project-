from django.urls import path, include
from store.middleware import auth_middleware
from store.views import index, signup, signin,signout, Cart, Checkout, Order_view

urlpatterns = [
    path('', index.as_view(), name='home_page'),
    path('signup/', signup.as_view(), name='signup'),
    path('signin/', signin.as_view(), name='login'),
    path('signout/', signout, name='signout'),
    path('cart/', Cart.as_view(), name='cart'),
    path('check_out', Checkout.as_view(), name='checkout'),
    path('order_view/', auth_middleware(Order_view.as_view()), name='order_view'),
]
