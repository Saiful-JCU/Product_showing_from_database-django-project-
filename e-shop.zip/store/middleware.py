from django.shortcuts import redirect
from django.urls import reverse
from urllib.parse import urlencode

def auth_middleware(get_response):

    def middleware(request):
        return_url = request.get_full_path()  # Full path of the current request
        if not request.session.get('customer_id'):
            # Reverse the URL for 'signin' and append the return_url query parameter
            signin_url = reverse('login')  # Use reverse() for URL resolution
            query_params = urlencode({'return_url': return_url})
            return redirect(f'{signin_url}?{query_params}')
        response = get_response(request)
        return response

    return middleware
