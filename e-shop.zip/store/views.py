from itertools import product

from django.contrib.auth import login
from django.template.context_processors import request
from django.utils.decorators import method_decorator
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password

from store.middleware import auth_middleware
from store.models import Product, Category, Customer, Order
from django.views import View


# Create your views here.
class index(View):

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1 :
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart before redirect ', request.session['cart'])
        #below code for checking the login method
        print("Session data:", request.session.items())

        customer_id = request.session.get('customer_id')
        if customer_id:
            # Fetch customer details
            customer = Customer.objects.get(id=customer_id)
            print("Logged in as:", customer.email)
        else:
            print("No user logged in.")

        return redirect('home_page')

    def get(self, request):
        prod = None
        # request.session.clear()
        category1 = Category.get_all_category()
        categoryID = request.GET.get('category')

        if categoryID:
            prod = Product.get_all_product_by_id(categoryID)
        else:
            prod = Product.get_all_product()

        # # Ensure cart is initialized
        # cart = request.session.get('cart', {})
        # request.session['cart'] = cart
        # # Debug: Print the cart after initializing
        # print("Cart after initializing:", cart)

        context = {'products': prod, 'categories': category1}
        return render(request, 'index.html', context)


class signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        error_message = None
        # get the data
        first_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        email = request.POST.get('email')
        password = request.POST.get('pass')
        print(first_name, last_name, email, password)
        # customer objects
        customer = Customer(first_name=first_name, last_name=last_name, email=email, password=password)

        # Form validation
        if not first_name:
            error_message = "First Name Required!!"
        elif len(first_name) < 3:
            error_message = "First name must be 3 char long or more!!"
        elif not last_name:
            error_message = "Last name Required!!"
        elif len(last_name) < 3:
            error_message = "Last name must be 3 char long or more!!"
        elif not email:
            error_message = "Email Address Required!!"
        elif customer.isExist():
            error_message = "Email Address Already registered!!"
        elif not password:
            error_message = "Password Required!!"
        elif len(password) < 6:
            error_message = "Password must be 6 char long or more!!"

        if not error_message:
            # password hashing
            customer.password = make_password(customer.password)
            # Register customer
            customer.register()
            print(customer)
            return redirect('home_page')
        else:
            content = {"error": error_message, 'first_name':first_name,'last_name':last_name, 'email':email}
            return render(request, 'signup.html', content)

        # Ensure the view always returns a response
        # return render(request, 'signup.html', {"error": "Unexpected error"})


class signin(View):
    returnUrl = None
    def get(self, request):
        signin.returnUrl= request.GET.get('return_url')
        return render(request, 'signin.html')

    def post(self,request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        error_message = None
        customer = Customer.get_customer_by_email(email)
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer_id'] = customer.id
                request.session['email'] = customer.email
                print('you are ',request.session.get('email'))
                if signin.returnUrl:
                    return HttpResponseRedirect(signin.returnUrl)
                else:
                    signin.returnUrl = None
                    return redirect('login')
            else:

                error_message = "Email or Password Invalid!!"
        else:
            error_message = "Email or Password Invalid!!"
        return render(request, 'signin.html',{'error':error_message} )


def signout(request):
    request.session.clear()
    return redirect('login')


class Cart(View):
    def get(self, request):
        # Ensure the cart exists in the session, if not set it to an empty dictionary
        cart = request.session.get('cart', {})
        if not cart:
            # If the cart is empty, you can return a message or handle it in the template
            return render(request, 'cart.html', {'message': 'Your cart is empty'})

        ids =  list(request.session.get('cart').keys())
        product = Product.get_products_by_id(ids)

        return render(request, 'cart.html', {'products':product})


class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer_id = request.session.get('customer_id')
        if not customer_id:
            # Handle the case where the customer ID is not in the session
            return redirect('login')  # Redirect to the login page if not signed in
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        customer = Customer.objects.get(id=customer_id)
        print(address,phone,customer,cart,products)
        for product in products:
            order = Order(customer= customer,
                          product = product,
                          price = product.price,
                          address = address,
                          phone = phone,
                          quantity = cart.get(str(product.id)),
                          status = True)
            order.save()
        #     this below code will delete all the products after placed order
        request.session['cart'] = {}
        return redirect('cart')


class Order_view(View):

    # @method_decorator(auth_middleware)
    def get(self,request):
        customer = request.session.get('customer_id')
        #
        if not customer:
            return redirect('login')  # Handle the case when the customer ID is not found

        orders = Order.get_orders_by_customer(customer)
        print('your currents ', orders)
        return render(request, 'order.html', {'orders':orders})




