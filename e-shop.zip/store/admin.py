from django.contrib import admin

from store.models import Product, Category, Customer, Order

# Register your models here.

admin.site.register(Product)
admin.site.register(Category)
admin.site.register(Customer)

class AdminOrder(admin.ModelAdmin):
    list_display = ['customer', 'product', 'quantity', 'price', 'date', 'address' ]

admin.site.register(Order, AdminOrder)